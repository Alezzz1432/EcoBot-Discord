import discord
from discord.ext import commands
import aiohttp
import random
import time

FREEPIK_API_KEY = "FPSX62011e8c1454f918428ddeedd4858244"
BOT_TOKEN = "MTM4OTAyODI4NzM3NTg3MjEyMQ.GKfAff.vzwU4yCRHxgDK__GukS4Jfu36WAmgCH_-yNQ80"

intents = discord.Intents.default()
intents.message_content = True
client = commands.Bot(command_prefix='!', intents=intents)

ultimo_envio = {}

async def obtener_imagenes_reciclaje():
    url = "https://api.freepik.com/v1/resources/search"
    params = {
        "q": "reciclaje",
        "locale": "es-ES",
        "type": "photo",
        "limit": 10
    }
    headers = {
        "apikey": FREEPIK_API_KEY
    }

    async with aiohttp.ClientSession() as session:
        async with session.get(url, headers=headers, params=params) as response:
            if response.status == 200:
                data = await response.json()
                return [item["assets"]["preview"]["url"] for item in data.get("data", [])]
            else:
                print("Error al obtener imágenes:", response.status)
                return []

@client.event
async def on_ready():
    print(f"Bot conectado como {client.user}")

@client.command(name='image')
async def enviar_imagen(ctx):
    ahora = time.time()
    imagenes = await obtener_imagenes_reciclaje()

    if not imagenes:
        await ctx.send("No se pudieron obtener imágenes. Intenta más tarde.")
        return

    disponibles = [img for img in imagenes if img not in ultimo_envio or ahora - ultimo_envio[img] > 300]

    if not disponibles:
        await ctx.send("Todas las imágenes han sido enviadas recientemente. Espera unos minutos.")
        return

    imagen_url = random.choice(disponibles)
    ultimo_envio[imagen_url] = ahora
    await ctx.send(imagen_url)

client.run(BOT_TOKEN)